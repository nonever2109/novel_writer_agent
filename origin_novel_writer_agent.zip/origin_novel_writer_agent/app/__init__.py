"""Novel writer agent package."""
